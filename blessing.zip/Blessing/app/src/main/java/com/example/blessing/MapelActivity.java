package com.example.blessing;

import androidx.annotation.LongDef;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.text.Html;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.example.blessing.Adapter.CustomRecyclerViewListener;
import com.example.blessing.Adapter.MapelAdapter;
import com.example.blessing.Adapter.OnItemClickListener;
import com.example.blessing.Model.MapelModel;
import com.example.blessing.Service.API;
import com.example.blessing.Service.RetrofitBuildCustom;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MapelActivity extends AppCompatActivity implements OnItemClickListener{
    private RecyclerView recyclerView;
    private ArrayList<MapelModel> mLearningModelArrayList;
    private MapelAdapter mAdapter;
    private OnItemClickListener onItemClickListener;
    private long mLastClickTime = 0;
    private API service;
    public static final String EXTRA_MAPEL = "MapelDetail";

    private String[] TextList = new String[]{"Matematika Dasar", "Bahasa Inggris", "Fisika", "Biologi", "Kimia"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mapel);
        service = RetrofitBuildCustom.getInstance().getService();

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setTitle(Html.fromHtml("<font color='#000000'> Mata Pelajaran </font>"));

        recyclerView = (RecyclerView) findViewById(R.id.text_learning);
//        mAdapter = new MapelAdapter(new ArrayList<MapelModel>(), this, new CustomRecyclerViewListener() {
//            @Override
//            public void onItemClick(String id) {
//                if (SystemClock.elapsedRealtime() - mLastClickTime < 1000) {
//                    return;
//                }
//                mLastClickTime = SystemClock.elapsedRealtime();
//
//            }
//        });
        recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.VERTICAL, false));
        recyclerView.setAdapter(mAdapter);

        mAdapter = new MapelAdapter(MapelActivity.this, mLearningModelArrayList);
        recyclerView.setAdapter(mAdapter);
        mAdapter.setOnItemClickListener(MapelActivity.this);

        getDataMapel();
    }

    public void getDataMapel() {
        service.getdatamapel().enqueue(new Callback<List<MapelModel>>() {
            @Override
            public void onResponse(Call<List<MapelModel>> call, Response<List<MapelModel>> response) {
                if (response.isSuccessful()) {
                    if (response.body() != null) {
                        mAdapter.updatedata(response.body());
                    }
                }
            }

            @Override
            public void onFailure(Call<List<MapelModel>> call, Throwable t) {

            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.create_menu, menu);
        new Handler().post(new Runnable() {
                               @Override
                               public void run() {
                                   final View view = findViewById(R.id.btnadd);
                                   if (view != null) {
                                       view.setOnLongClickListener(new View.OnLongClickListener() {
                                           @Override
                                           public boolean onLongClick(View v) {

                                               // Do something...

                                               Toast.makeText(getApplicationContext(), "Long pressed", Toast.LENGTH_SHORT).show();
                                               return true;
                                           }
                                       });
                                   }
                               }
                           }
        );
        return super.onCreateOptionsMenu(menu);
    }

    private void makemoveactivity(Class activity) {
        Intent intent = new Intent(this, activity);
        this.startActivity(intent);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.btnadd:
//                Toast.makeText(this, "selected", Toast.LENGTH_SHORT);
                makemoveactivity(CreateMapelActivity.class);
                return true;
        }
        int id = item.getItemId();

        if (id == android.R.id.home) {
//            this.finish();
            Intent moveIntent = new Intent(MapelActivity.this, MainActivity.class);
            startActivity(moveIntent);
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onItemClickListener(int position) {
        Intent intent = new Intent(this, MateriActivity.class);
        Log.d("", "onItemClickListener: " + position);
        MapelModel clickMapel = mLearningModelArrayList.get(position);

        intent.putExtra(EXTRA_MAPEL, clickMapel.getNamaMapel());
        startActivity(intent);
    }

    @Override
    public void onRestart()
    {
        super.onRestart();
        finish();
        startActivity(getIntent());
    }
}


