package com.example.blessing.Adapter;

public interface OnItemClickListener {

    void onItemClickListener(int position);
}
