package com.example.blessing.Adapter;

public interface CustomRecyclerViewListener {

    void onItemClick(String id);

}

